<?PHP
include "../entities/produit.php";
include "../core/produitC.php";
$produit=new Produit(345678,"Yaourt",100,619000,"alimentaire","yaourt",25,"Fournisseur1");
$produitC=new ProduitC();
$produitC->afficherProduit($produit);
echo "****************";
echo "<br>";
echo "id:".$produit->getId();
echo "<br>";
echo "nom:".$produit->getNom();
echo "<br>";
echo "prix:".$produit->getPrix();
echo "<br>";
echo "code:".$produit->getCode();
echo "<br>";
echo "categorie:".$produit->getCategorie();
echo "<br>";
echo "type:".$produit->getType();
echo "<br>";
echo "stock:".$produit->getStock();
echo "<br>";
echo "stock:".$produit->getNomf();
echo "<br>";


?>
