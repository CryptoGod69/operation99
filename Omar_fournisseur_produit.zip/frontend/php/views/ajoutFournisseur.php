<?PHP
include "../entities/fournisseur.php";
include "../core/fournisseurC.php";

if (($_POST['id']) and isset($_POST['nom']) and isset($_POST['email']) and isset($_POST['mat']) and isset($_POST['rib']) and isset($_POST['tel'])){
$fournisseur1=new Fournisseur($_POST['id'],$_POST['nom'],$_POST['email'],$_POST['mat'],$_POST['rib'],$_POST['tel']);
//Partie2
/*
var_dump($employe1);
}
*/
//Partie3
$fournisseur1C=new FournisseurC();
$fournisseur1C->ajouterFournisseur($fournisseur1);
header('Location: afficherFournisseur.php');
	
}else{
	echo "vérifier les champs";
}
//*/

?>