<?PHP
include "../core/fournisseurC.php";
$fournisseur1C=new FournisseurC();
$listeFournisseurs=$Fournisseur1C->afficherFournisseur();

//var_dump($listeFournisseurs->fetchAll());
?>
<table border="1">
<tr>
<td>id</td>
<td>Nom</td>
<td>Matricule</td>
<td>RIB</td>
<td>supprimer</td>
<td>modifier</td>
</tr>

<?PHP
foreach($listeFournisseur as $row){
	?>
	<tr>
    <td><?PHP echo $row['id']; ?></td>
	<td><?PHP echo $row['nom']; ?></td>
	<td><?PHP echo $row['mat']; ?></td>
	<td><?PHP echo $row['rib']; ?></td>
	<td><form method="POST" action="supprimerFournisseur.php">
	<input type="submit" name="supprimer" value="supprimer">
	<input type="hidden" value="<?PHP echo $row['id']; ?>" name="id">
	</form>
	</td>
	<td><a href="modifierFournisseur.php?id=<?PHP echo $row['id']; ?>">
	Modifier</a></td>
	</tr>
	<?PHP
}
?>
</table>


