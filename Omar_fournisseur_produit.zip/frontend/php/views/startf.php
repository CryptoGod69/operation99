<?PHP
include "../entities/fournisseur.php";
include "../core/fournisseurC.php";
$fournisseur=new Fournisseur(234567,"BEN Ahmed",45678,3456789);
$fournisseurC=new FournisseurC();
$FournisseurC->afficherFournisseur($fournisseur);
echo "****************";
echo "<br>";
echo "id:".$fournisseur->getId();
echo "<br>";
echo "nom:".$fournisseur->getNom();
echo "<br>";
echo "mat:".$fournisseur->getMat();
echo "<br>";
echo "rib:".$fournisseur->getRIB();
echo "<br>";


?>
