<?PHP
include "../core/produitC.php";
$produit1C=new ProduitC();
$listeProduits=$Produit1C->afficherProduit();

//var_dump($listeEmployes->fetchAll());
?>
<table border="1">
<tr>
<td>id</td>
<td>Nom produit</td>
<td>Prix</td>
<td>Code</td>
<td>Categorie</td>
<td>Type</td>
<td>Stock</td>
<td>Nom fournisseur</td>
<td>supprimer</td>
<td>modifier</td>
</tr>

<?PHP
foreach($listeProduit as $row){
	?>
	<tr>
    <td><?PHP echo $row['id']; ?></td>
	<td><?PHP echo $row['nom']; ?></td>
	<td><?PHP echo $row['prix']; ?></td>
	<td><?PHP echo $row['code']; ?></td>
    <td><?PHP echo $row['categorie']; ?></td>
    <td><?PHP echo $row['type']; ?></td>
    <td><?PHP echo $row['stock']; ?></td>
    <td><?PHP echo $row['nomf']; ?></td>
	<td><form method="POST" action="supprimerProduit.php">
	<input type="submit" name="supprimer" value="supprimer">
	<input type="hidden" value="<?PHP echo $row['id']; ?>" name="id">
	</form>
	</td>
	<td><a href="modifierProduit.php?id=<?PHP echo $row['id']; ?>">
	Modifier</a></td>
	</tr>
	<?PHP
}
?>
</table>


