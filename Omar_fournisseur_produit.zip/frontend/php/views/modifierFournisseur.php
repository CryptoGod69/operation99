<HTML>
<head>
</head>
<body>
<?PHP
include "../entities/fournisseur.php";
include "../core/fournisseurC.php";
if (isset($_GET['id'])){
	$fournisseurC=new FournisseurC();
    $result=$fournisseurC->recupererFournisseur($_GET['id']);
	foreach($result as $row){
		$id=$row['id'];
		$nom=$row['nom'];
		$prenom=$row['mat'];
		$nbH=$row['rib'];
?>
<form method="POST">
<table>
<caption>Modifier Fournisseur</caption>
<tr>
<td>ID</td>
<td><input type="number" name="id" value="<?PHP echo $id ?>"></td>
</tr>
<tr>
<td>Nom</td>
<td><input type="text" name="nom" value="<?PHP echo $nom ?>"></td>
</tr>
<tr>
<td>Matricule</td>
<td><input type="text" name="mat" value="<?PHP echo $mat ?>"></td>
</tr>
<tr>
<td>RIB</td>
<td><input type="number" name="rib" value="<?PHP echo $rib ?>"></td>
</tr>
<tr>
<td></td>
<td><input type="submit" name="modifier" value="modifier"></td>
</tr>
<tr>
<td></td>
<td><input type="hidden" name="id_ini" value="<?PHP echo $_GET['id'];?>"></td>
</tr>
</table>
</form>
<?PHP
	}
}
if (isset($_POST['modifier'])){
	$fournisseur=new fournisseur($_POST['id'],$_POST['nom'],$_POST['mat'],$_POST['rib']);
	$fournisseurC->modifierFournisseur($fournisseur,$_POST['id']);
	echo $_POST['id'];
	header('Location: afficherFournisseur.php');
}
?>
</body>
</HTMl>
