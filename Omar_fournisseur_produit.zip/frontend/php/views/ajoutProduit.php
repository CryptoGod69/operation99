<?PHP
include "../entities/produit.php";
include "../core/produitC.php";

if (($_POST['id']) and isset($_POST['nom']) and isset($_POST['prix']) and isset($_POST['code']) and isset($_POST['categorie']) and isset($_POST['type']) and isset($_POST['stock']) and isset($_POST['nomf'])){
$produit1=new Produit($_POST['id'],$_POST['nom'],$_POST['prix'],$_POST['code'],$_POST['categorie'],$_POST['type'],$_POST['stock'],$_POST['nomf']);
//Partie2
/*
var_dump($employe1);
}
*/
//Partie3
$produit1C=new ProduitC();
$produit1C->ajouterProduit($produit1);

	
}else{
	echo "vérifier les champs";
}
//*/

?>
