<?PHP
include "../config.php";
class ProduitC{
function afficherProduit ($produit){
        echo "ID produit: ".$produit->getId()."<br>";
		echo "Nom produit: ".$produit->getNom()."<br>";
		echo "Prix: ".$produit->getPrix()."<br>";
		echo "Code: ".$produit->getCode()."<br>";
		echo "Categorie: ".$produit->getCategorie()."<br>";
        echo "Type: ".$produit->getType()."<br>";
        echo "Stock: ".$produit->getStock()."<br>";
        echo "Nom fournisseur: ".$produit->getNomf()."<br>";
    
		}

function ajouterProduit($produit){
    $sql="insert into produit (id,nom,prix,code,categorie,type,stock,nomf) values (:id,:nom,:prix,:code,:categorie,:type,:stock,:nomf)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $id=$produit->getId();
        $nom=$produit->getNom();
        $prix=$produit->getPrix();
        $code=$produit->getCode();
        $categorie=$produit->getCategorie();
        $type=$produit->getType();
        $stock=$produit->getStock();
        $nomf=$produit->getNomf();
        $req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':code',$code);
		$req->bindValue(':categorie',$categorie);
        $req->bindValue(':type',$type);
        $req->bindValue(':stock',$stock);
        $req->bindValue(':nomf',$nomf);
            
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage("");
        }
		
		}
	
	function afficherProduit(){
		//$sql="SElECT * From PRODUIT e inner join formationphp.PRODUIT a on e.cin= a.cin";
		$sql="SElECT * From PRODUIT";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
		}
	function supprimerProduit($id){
		$sql="DELETE FROM PRODUIT where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
		}
	function modifierProduit($produit,$id,$nom,$prix,$code,$categorie,$type,$stock,$nomf){
        $sql="UPDATE PRODUIT SET nom=:nom,prix=:prix,code=:code,categorie=:categorie,type=:type,stock=:stock,nomf=:nomf WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
	try{		
        $req=$db->prepare($sql);
        $nom=$produit->getNom();
        $prix=$produit->getPrix();
        $code=$produit->getCode();
        $categorie=$produit->getCategorie();
        $type=$produit->getType();
        $stock=$produit->getStock();
        $nomf=$produit->getNomf();
        $datas = array(':nom'=>$nom, ':prix'=>$prix,':code'=>$code, ':categorie'=>$categorie, ':type'=>$type, ':stock'=>$stock, ':nomf'=>$nomf);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':code',$code);
        $req->bindValue(':categorie',$categorie);
        $req->bindValue(':type',$type);
        $req->bindValue(':stock',$stock);
		$req->bindValue(':nomf',$nomf);
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   			echo " Les datas : " ;
  			print_r($datas);
        }
		
		}
		function recupererProduit($id){
		$sql="SELECT * from PRODUIT where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>
