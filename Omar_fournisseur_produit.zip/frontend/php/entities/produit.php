<?PHP
class Produit{
	private $id;
	private $nom;
	private $prix;
    private $code;
	private $categorie;
	private $type;
	private $stock;
	private $nomf;
	function __construct($id,$nom,$prix,$code,$categorie,$type,$stock){
		$this->id=$id;
		$this->nom=$nom;
		$this->prix=$prix;
		$this->code=$code;
		$this->categorie=$categorie;
		$this->type=$type;
		$this->stock=$stock;
		$this->nomf=$nomf;

	}
	
	function getId(){
		return $this->id;
	}
	function getNom(){
		return $this->nom;
	}
	function getPrix(){
		return $this->prix;
	}
	function getCode(){
		return $this->code;
	}
	function getCategorie(){
		return $this->categorie;
	}
	function getType(){
		return $this->type;
	}
	function getStock(){
		return $this->stock;
	}
	function getNomf(){
		return $this->nomf;
	}
	function setId($id){
		$this->id=$id;
	}
	function setNom($nom){
		$this->nom=$nom;
	}
	function setPrix($prix){
		$this->prix=$prix;
	}
	function setCode($code){
		$this->code=$code;
	}
	function setCategorie($catergorie){
		$this->categorie=$categorie;
	}
	function setType($type){
		$this->type=$type;
	}
	function setStock($stock){
		$this->stock=$stock;
	}
	function setNomf($stock){
		$this->nomf=$nomf;
	}
	
}

?>