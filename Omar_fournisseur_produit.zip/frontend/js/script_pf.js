function add_f(){
	var Idp = document.getElementById("idp")
	var Nomf = document.getElementById("Nomf")
	var Matricule = document.getElementById("Matricule");
	var RIB = document.getElementById("RIB");

	if(isNaN(matricule)||isNaN(RIB)){
		alert("Veuillez entrer toutes les informations Fournisseur demandées.");
	}else if(RIB != 23){
		alert("Veuillez entrer un RIB valide.");
	}else{
		//PHP
		alert("Merci d'avoir ajouté un fournisseur");
	}
}

function add_p(){
	var Idf = document.getElementById("idf")
	var Nom = document.getElementById("Nomprod");
	var Prix = document.getElementById("Prix");
	var Code = document.getElementById("Code");
	var Categorie = document.getElementById("Categorie");
	var Type = document.getElementById("Type");
	var Stock = document.getElementById("Stock");
	var Nomf = document.getElementById("Nomf");
	if(isNaN(Idp)||isNaN(Nomprod)||isNaN(Prix)||isNaN(Code)||isNaN(Categorie)||isNaN(Type)||isNaN(Stock)||isNaN(Nomf)){
		alert("Veuillez entrer toutes les informations Produit demandées.");
	}else{
		//PHP
		alert("Merci d'avoir ajouté un nouveau produit");
	}
}