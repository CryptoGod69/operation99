<?PHP
include "../entities/fournisseur.php";
include "../core/fournisseurC.php";

if (isset($_POST['id']) and isset($_POST['nom']) and isset($_POST['mat']) and isset($_POST['rib'])){
$fournisseur1=new Fournisseur($_POST['id'],$_POST['nom'],$_POST['mat'],$_POST['rib']);
//Partie2

//var_dump($employe1);


//Partie3
$fournisseur1C=new FournisseurC();
$fournisseur1C->ajouterFournisseur($fournisseur1);
//header('Location: afficherFournisseur.php');
	
}else{
	echo "vérifier les champs";
}
//*/

?>