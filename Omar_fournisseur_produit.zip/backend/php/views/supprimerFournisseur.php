<?PHP
include "../core/fournisseurC.php";
$fournisseurC=new FournisseurC();
if (isset($_POST["id"])){
	$fournisseurC->supprimerFournisseur($_POST["id"]);
	header('Location: supprimerFournisseur.php');
}

?>
