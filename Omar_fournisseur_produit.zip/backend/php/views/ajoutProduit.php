<?PHP
include "../entities/produit.php";
include "../core/produitC.php";

if (true){
$produit1=new Produit($_POST['id'],$_POST['nom'],$_POST['prix'],$_POST['code'],$_POST['categorie'],$_POST['type'],$_POST['stock'],$_POST['nomf']);
//Partie2
/*
var_dump($employe1);
}
*/
//Partie3
$produit1C=new ProduitC();
$produit1C->ajouterProduit($produit1);

	
}else{
	echo "vérifier les champs";
}
//*/

?>
