<HTML>
<head>
</head>
<body>
<?PHP
include "../entities/produit.php";
include "../core/produitC.php";
if (isset($_GET['id'])){
	$produitC=new ProduitC();
    $result=$produitC->recupererProduit($_GET['id']);
	foreach($result as $row){
		$id=$row['id'];
		$nom=$row['nom'];
		$prix=$row['prix'];
		$code=$row['code'];
		$categorie=$row['categorie'];
		$type=$row['type'];
		$stock=$row['stock'];
        $nomf=$row['nomf'];
/*?>
<form method="POST">
<table>
<caption>Modifier Produit</caption>
<tr>
<td>ID</td>
<td><input type="number" name="id" value="<?PHP echo $id ?>"></td>
</tr>
<tr>
<td>Nom</td>
<td><input type="text" name="nom" value="<?PHP echo $nom ?>"></td>
</tr>
<tr>
<td>Prix</td>
<td><input type="number" name="prix" value="<?PHP echo $prix ?>"></td>
</tr>
<tr>
<td>Code</td>
<td><input type="number" name="code" value="<?PHP echo $code ?>"></td>
</tr>
<tr>
<td>Categorie</td>
<td><input type="text" name="categorie" value="<?PHP echo $categorie ?>"></td>
</tr>
<tr>
<td>Type</td>
<td><input type="text" name="type" value="<?PHP echo $type ?>"></td>
</tr>
<tr>
<td>Stock</td>
<td><input type="number" name="stock" value="<?PHP echo $stock ?>"></td>
</tr>
<tr>
<td>Stock</td>
<td><input type="text" name="nomf" value="<?PHP echo $stock ?>"></td>
</tr>
<tr>
<td></td>
<td><input type="submit" name="modifier" value="modifier"></td>
</tr>
<tr>
<td></td>
<td><input type="hidden" name="id_ini" value="<?PHP echo $_GET['id'];?>"></td>
</tr>
</table>
</form>
<?PHP*/
	}
}
if (true){
	$produit=new produit($_POST['id'],$_POST['nom'],$_POST['prix'],$_POST['code'],$_POST['categorie'],$_POST['type'],$_POST['stock'],$_POST['nomf']);
	$produitC->modifierProduit($produit,$_POST['id']);
	echo $_POST['id'];
	header('Location: afficherProduit.php');
}
?>
</body>
</HTMl>
