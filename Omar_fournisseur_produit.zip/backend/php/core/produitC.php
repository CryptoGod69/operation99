<?PHP
include "config.php";
class ProduitC{

function ajouterProduit($produit){
    $sql="insert into produits (id,nom,prix,code,categorie,type,stock,nomf) values (:id,:nom,:prix,:code,:categorie,:type,:stock,:nomf)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $id=$produit->getId();
        $nom=$produit->getNom();
        $prix=$produit->getPrix();
        $code=$produit->getCode();
        $categorie=$produit->getCategorie();
        $type=$produit->getType();
        $stock=$produit->getStock();
        $nomf=$produit->getNomf();
        $req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':code',$code);
		$req->bindValue(':categorie',$categorie);
        $req->bindValue(':type',$type);
        $req->bindValue(':stock',$stock);
        $req->bindValue(':nomf',$nomf);
            
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
		}
	
	function afficherProduit(){
		//$sql="SElECT * From PRODUIT e inner join formationphp.PRODUIT a on e.cin= a.cin";
		$sql="SElECT * From PRODUITS";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
		}
	function supprimerProduit($id){
		$sql="DELETE FROM PRODUITS where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
		}
	function modifierProduit($produit,$id,$nom,$prix,$code,$categorie,$type,$stock,$nomf){
        $sql="UPDATE PRODUITS SET nom=:nom,prix=:prix,code=:code,categorie=:categorie,type=:type,stock=:stock,nomf=:nomf WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
	try{		
        $req=$db->prepare($sql);
        $nom=$produit->getNom();
        $prix=$produit->getPrix();
        $code=$produit->getCode();
        $categorie=$produit->getCategorie();
        $type=$produit->getType();
        $stock=$produit->getStock();
        $nomf=$produit->getNomf();
        $datas = array(':nom'=>$nom, ':prix'=>$prix,':code'=>$code, ':categorie'=>$categorie, ':type'=>$type, ':stock'=>$stock, ':nomf'=>$nomf);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':code',$code);
        $req->bindValue(':categorie',$categorie);
        $req->bindValue(':type',$type);
        $req->bindValue(':stock',$stock);
		$req->bindValue(':nomf',$nomf);
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   			echo " Les datas : " ;
  			print_r($datas);
        }
		
		}
		function recupererProduit($id){
		$sql="SELECT * from PRODUITS where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>
